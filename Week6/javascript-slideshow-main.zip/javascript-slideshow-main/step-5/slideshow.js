
var current = 0;
var total = 4;

var next = document.getElementById("next");

next.addEventListener("click", function(){

    console.log("NEXT");

});