
var current = 0;